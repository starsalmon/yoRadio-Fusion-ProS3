var irloaded = false;
function checkSelect() {
  var elements = document.getElementsByClassName("irradio");
  var chkid = 0;
  for (var i = 0; i < elements.length; i++) {
    elements[i].classList.remove("active");
    elements[i].parentElement.getElementsByClassName("irrecordvalue")[0].classList.remove("active");
    if (elements[i] === this) chkid = i;
  }
  var ts = this !== window ? this : elements[0];
  ts.classList.add("active");
  ts.parentElement.getElementsByClassName("irrecordvalue")[0].classList.add("active");
  if (this !== window) websocket.send('chkid=' + chkid);
  document.getElementById('protocol').innerText = "";
}

function irbuttonClick() {
  var elements = document.getElementsByClassName("irbutton");
  var hasactive = this.classList.contains("active");
  var btnid = -1;
  for (var i = 0; i < elements.length; i++) {
    elements[i].classList.remove("active");
    if (!hasactive && elements[i] == this) btnid = i;
  }
  if (!hasactive) {
    document.getElementById("irrecordtitle").innerHTML = 'REC codes for <span>' + this.innerHTML + '</span>';
    document.getElementById("irrecord").classList.remove("hidden");
    document.getElementById("irstartrecord").classList.add("hidden");
    this.classList.add("active");
    checkSelect();
  } else {
    document.getElementById("irrecord").classList.add("hidden");
    document.getElementById("irstartrecord").classList.remove("hidden");
  }
  document.getElementById('protocol').innerText = "";
  websocket.send('irbtn=' + btnid);
}

function backRecord() {
  var elements = document.getElementsByClassName("irbutton");
  for (var i = 0; i < elements.length; i++) {
    elements[i].classList.remove("active");
  }
  document.getElementById("irrecord").classList.add("hidden");
  document.getElementById("irstartrecord").classList.remove("hidden");
  websocket.send('irbtn=-1');
}

function irClear(el) {
  el.parentElement.getElementsByClassName("irrecordvalue")[0].innerText = "";
  document.getElementById('protocol').innerText = "";
  websocket.send('irclr=' + el.parentElement.getElementsByClassName("irradio")[0].getAttribute('data-id'));
}

function irSetStatus(msg, isError) {
  var s = document.getElementById('ir_backup_status');
  if (!s) return;
  s.textContent = msg;
  s.style.color = isError ? '#e53a3e' : '';
  if (msg) setTimeout(function(){ s.textContent = ''; s.style.color = ''; }, 3000);
}

function irDownload() {
  var xhr = new XMLHttpRequest();
  xhr.open('GET', '/ircodes.csv', true);
  xhr.responseType = 'blob';
  xhr.onload = function() {
    if (xhr.status === 404) {
      irSetStatus('No IR codes yet!', true);
      return;
    }
    if (xhr.status !== 200) {
      irSetStatus('Error!', true);
      return;
    }
    var a = document.createElement('a');
    a.href = URL.createObjectURL(xhr.response);
    a.download = 'ircodes.csv';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(function(){ document.body.removeChild(a); URL.revokeObjectURL(a.href); }, 100);
    irSetStatus('OK!', false);
  };
  xhr.onerror = function() { irSetStatus('Error!', true); };
  xhr.send();
}

function irUpload(input) {
  if (!input.files || !input.files[0]) return;
  irSetStatus('Uploading...', false);
  var fd = new FormData();
  fd.append('file', input.files[0], 'ircodes.csv');
  var xhr = new XMLHttpRequest();
  xhr.open('POST', '/webboard', true);
  xhr.onload = function() {
    irSetStatus(xhr.status === 200 ? 'OK!' : 'Error!', xhr.status !== 200);
  };
  xhr.onerror = function() { irSetStatus('Error!', true); };
  xhr.send(fd);
  input.value = '';
}

function initControls() {
  if (irloaded) return;
  irloaded = true;
  var elements = document.getElementsByClassName("irbutton");
  for (var i = 0; i < elements.length; i++) {
    elements[i].addEventListener('click', irbuttonClick, false);
  }
  elements = document.getElementsByClassName("irradio");
  for (var i = 0; i < elements.length; i++) {
    elements[i].addEventListener('click', checkSelect, false);
  }
}
